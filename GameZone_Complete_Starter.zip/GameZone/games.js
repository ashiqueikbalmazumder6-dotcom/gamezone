const GAMES = [
{"id": 1, "title": "Neon Tap Rush", "mode": "tap", "description": "Tap the glowing target 20 times before time runs out."},
{"id": 2, "title": "Color Blitz", "mode": "color", "description": "Tap the requested color as quickly as possible."},
{"id": 3, "title": "Math Sprint", "mode": "math", "description": "Solve 10 quick maths questions."},
{"id": 4, "title": "Memory Match", "mode": "memory", "description": "Find all matching pairs."},
{"id": 5, "title": "Reaction Test", "mode": "reaction", "description": "Wait for green, then tap as fast as you can."},
{"id": 6, "title": "Number Hunt", "mode": "number", "description": "Find the called number in the grid."},
{"id": 7, "title": "Word Scramble", "mode": "word", "description": "Unscramble the mixed-up word."},
{"id": 8, "title": "Sequence Master", "mode": "sequence", "description": "Remember and repeat the growing sequence."},
{"id": 9, "title": "Target Practice", "mode": "tap", "description": "Hit 20 moving-style targets (new target each hit)."},
{"id": 10, "title": "Quick Count", "mode": "math", "description": "Answer 10 counting challenges."},
{"id": 11, "title": "Color Switch", "mode": "color", "description": "Match the color prompt."},
{"id": 12, "title": "Brain Trainer", "mode": "math", "description": "Solve 10 brain-training questions."},
{"id": 13, "title": "Flash Memory", "mode": "memory", "description": "Match the hidden symbols."},
{"id": 14, "title": "Speed Clicker", "mode": "tap", "description": "Reach 25 taps before the clock ends."},
{"id": 15, "title": "Fast Fingers", "mode": "reaction", "description": "Test your reaction speed."},
{"id": 16, "title": "Number Puzzle", "mode": "number", "description": "Find the correct number in a grid."},
{"id": 17, "title": "Word Master", "mode": "word", "description": "Unscramble a new word each round."},
{"id": 18, "title": "Pattern Recall", "mode": "sequence", "description": "Repeat the pattern correctly."},
{"id": 19, "title": "Neon Reflex", "mode": "reaction", "description": "Wait for the signal and react."},
{"id": 20, "title": "Gem Match", "mode": "memory", "description": "Match the gem symbols."},
{"id": 21, "title": "Quick Maths Pro", "mode": "math", "description": "Solve mixed arithmetic questions."},
{"id": 22, "title": "Color Finder", "mode": "color", "description": "Find the target color."},
{"id": 23, "title": "Tap Mania", "mode": "tap", "description": "Tap the target 30 times."},
{"id": 24, "title": "Lucky Number", "mode": "number", "description": "Find the target number."},
{"id": 25, "title": "Letter Jumble", "mode": "word", "description": "Rearrange letters to form a word."},
{"id": 26, "title": "Brain Sequence", "mode": "sequence", "description": "Repeat the growing pattern."},
{"id": 27, "title": "Arcade Reflex", "mode": "reaction", "description": "React when the signal turns green."},
{"id": 28, "title": "Symbol Match", "mode": "memory", "description": "Match all symbol pairs."},
{"id": 29, "title": "Turbo Tap", "mode": "tap", "description": "Score as many taps as possible."},
{"id": 30, "title": "Ultimate Brain Mix", "mode": "math", "description": "Complete 10 mixed maths rounds."}
];
const icons={tap:"⚡",color:"🎨",math:"🧠",memory:"💎",reaction:"🚀",number:"🔢",word:"🔤",sequence:"🧩"};
const grid=document.getElementById('grid'), search=document.getElementById('search'), filter=document.getElementById('filter');
function render(){const q=search.value.toLowerCase(),f=filter.value;grid.innerHTML='';GAMES.filter(g=>(f==='all'||g.mode===f)&&(g.title.toLowerCase().includes(q)||g.description.toLowerCase().includes(q))).forEach(g=>{let d=document.createElement('article');d.className='game';d.innerHTML=`<div class="emoji">${icons[g.mode]}</div><h3>${g.id.toString().padStart(2,'0')}. ${g.title}</h3><p>${g.description}</p><button>PLAY GAME</button>`;d.querySelector('button').onclick=()=>startGame(g);grid.appendChild(d)})}
search.oninput=render;filter.onchange=render;render();
let timer=null,score=0,round=0,current=null,answer=null,sequence=[],phase=0;
const $=id=>document.getElementById(id);
function startGame(g){clearInterval(timer);current=g;score=0;round=0;phase=0;$('gameTitle').textContent=g.title;$('instructions').textContent=g.description;$('status').textContent='';$('modal').classList.add('show');nextRound()}
function closeGame(){clearInterval(timer);$('modal').classList.remove('show')}
function area(html){$('area').innerHTML=html}
function say(t){$('status').textContent=t}
function finish(msg){clearInterval(timer);area(`<div class="big">${score} points</div><p>${msg}</p><button onclick="startGame(current)">PLAY AGAIN</button>`);say('Game complete!')}
function nextRound(){
 const m=current.mode;
 if(m==='tap'){let goal=current.id%2?20:25;area(`<div class="big">${score} / ${goal}</div><p>Tap the energy button as fast as you can!</p><button id="hit" style="font-size:24px;padding:22px 34px">⚡ TAP!</button>`);$('hit').onclick=()=>{score++;if(score>=goal)finish('Amazing tapping!');else $('area').querySelector('.big').textContent=score+' / '+goal}}
 else if(m==='reaction'){area(`<p>Wait for the green signal...</p><div class="big" id="signal">🔴 WAIT</div><button id="react" disabled>WAIT</button>`);let ready=false,at=0;let delay=1200+Math.random()*3000;timer=setTimeout(()=>{ready=true;at=Date.now();$('signal').textContent='🟢 TAP NOW!';$('react').disabled=false;$('react').textContent='TAP!'},delay);$('react').onclick=()=>{if(!ready){clearTimeout(timer);say('Too early! Try again.');startGame(current)}else{let ms=Date.now()-at;score=ms;$('signal').textContent=ms+' ms';say(ms<250?'Lightning fast!':ms<400?'Great reaction!':'Good try!');$('react').textContent='TRY AGAIN';$('react').onclick=()=>startGame(current)}}}
 else if(m==='math'){if(round>=10){finish('Math champion!');return}round++;let a=2+Math.floor(Math.random()*18),b=1+Math.floor(Math.random()*12),op=['+','−','×'][Math.floor(Math.random()*3)];answer=op==='+'?a+b:op==='−'?a-b:a*b;area(`<div class="hint">QUESTION ${round} / 10</div><div class="big">${a} ${op} ${b} = ?</div><input id="ans" type="number" style="padding:12px;border-radius:9px;width:120px"><button id="check">CHECK</button>`);$('check').onclick=()=>{if(Number($('ans').value)===answer){score+=10;say('Correct! +10')}else say('Correct answer: '+answer);setTimeout(nextRound,650)}}
 else if(m==='color'){let colors=['RED','BLUE','GREEN','YELLOW'],c=colors[Math.floor(Math.random()*4)];area(`<div class="big">${c}</div><p>Tap the matching color</p><div class="choices">${colors.map(x=>`<button data-c="${x}" style="background:${x.toLowerCase()};color:${x==='YELLOW'?'#111':'white'}">${x}</button>`).join('')}</div>`);document.querySelectorAll('[data-c]').forEach(b=>b.onclick=()=>{if(b.dataset.c===c){score+=10;say('Correct!')}else say('Try to focus!');round++;if(round>=10)finish('Color master!');else setTimeout(nextRound,500)})}
 else if(m==='number'){let nums=Array.from({length:12},()=>Math.floor(Math.random()*50)+1),target=nums[Math.floor(Math.random()*nums.length)];area(`<p>Find number <b style="color:var(--cyan)">${target}</b></p><div class="choices">${nums.map(n=>`<button data-n="${n}" class="secondary">${n}</button>`).join('')}</div>`);document.querySelectorAll('[data-n]').forEach(b=>b.onclick=()=>{if(+b.dataset.n===target){score+=10;say('Found it!')}else say('Not that one!');round++;if(round>=8)finish('Sharp eyes!');else setTimeout(nextRound,450)})}
 else if(m==='word'){let words=['PLANET','GAMING','PUZZLE','ROCKET','JUNGLE','CASTLE','DRAGON','PLAYER','MEMORY','ARCADE'],w=words[Math.floor(Math.random()*words.length)],scr=w.split('').sort(()=>Math.random()-.5).join('');if(scr===w)scr=w.slice(1)+w[0];answer=w;area(`<div class="hint">ROUND ${round+1} / 5</div><div class="big">${scr}</div><input id="ans" placeholder="Your answer" style="padding:12px;border-radius:9px;text-transform:uppercase"><button id="check">SUBMIT</button>`);$('check').onclick=()=>{if($('ans').value.trim().toUpperCase()===answer){score+=20;say('Correct!')}else say('Answer: '+answer);round++;if(round>=5)finish('Word wizard!');else setTimeout(nextRound,700)}}
 else if(m==='sequence'){if(phase===0){sequence=Array.from({length:4},()=>Math.floor(Math.random()*4));phase=1;area(`<p>Memorise this sequence</p><div class="big">${sequence.map(n=>['🔴','🔵','🟢','🟡'][n]).join(' ')}</div><button id="ready">I'M READY</button>`);$('ready').onclick=()=>{phase=2;sequenceInput()}}}
 else if(m==='memory'){let symbols=['🍒','⭐','🚀','💎','🎮','🍀'],pairs=[...symbols.slice(0,4),...symbols.slice(0,4)].sort(()=>Math.random()-.5),opened=[],matched=[];area(`<p>Tap two cards to find matching pairs</p><div class="choices" id="cards">${pairs.map((x,i)=>`<button class="secondary" data-i="${i}" style="width:65px;height:58px;font-size:23px">❔</button>`).join('')}</div>`);document.querySelectorAll('[data-i]').forEach(b=>b.onclick=()=>{let i=+b.dataset.i;if(opened.includes(i)||matched.includes(i)||opened.length===2)return;opened.push(i);b.textContent=pairs[i];if(opened.length===2){if(pairs[opened[0]]===pairs[opened[1]]){matched.push(...opened);score+=10;say('Match!')}setTimeout(()=>{opened.forEach(k=>{if(!matched.includes(k))document.querySelector(`[data-i="${k}"]`).textContent='❔'});opened=[];if(matched.length===8)finish('Perfect memory!')},650)}})}
}
function sequenceInput(){let chosen=[];area(`<p>Repeat the sequence</p><div class="choices">${['🔴','🔵','🟢','🟡'].map((x,i)=>`<button data-s="${i}" style="font-size:22px">${x}</button>`).join('')}</div><div id="progress" class="hint">0 / ${sequence.length}</div>`);document.querySelectorAll('[data-s]').forEach(b=>b.onclick=()=>{chosen.push(+b.dataset.s);$('progress').textContent=chosen.length+' / '+sequence.length;if(chosen[chosen.length-1]!==sequence[chosen.length-1]){finish('Sequence ended. Try again!');return}if(chosen.length===sequence.length){score=sequence.length*20;finish('Perfect sequence recall!')}})}
window.startGame=startGame;window.closeGame=closeGame;
