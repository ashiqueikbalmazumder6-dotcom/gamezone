GAMEZONE STARTER PROJECT
========================
Included:
- index.html: responsive dark 3D-style gaming portal
- games.js: 30 listed mini-games using 8 playable game mechanics
- manifest.webmanifest + sw.js: installable PWA/offline app shell
- icon.svg: app icon
- privacy.html: starter privacy notice (replace contact email)
- games.json: game catalogue

RUN LOCALLY
Open index.html in a modern browser. For PWA install/offline testing, serve this folder over HTTPS or localhost (service workers do not work from file://).

FREE WEBSITE HOSTING
1. Create a GitHub account and a new public repository named gamezone.
2. Upload all files in this folder to the repository root.
3. Open Settings > Pages > Deploy from a branch > main > /(root) > Save.
4. Wait for the Pages URL, then open it on Android Chrome.
5. Test every game and the install prompt.

ANDROID INSTALL
- Open the HTTPS website in Chrome on Android.
- Use browser menu > Install app / Add to Home screen.
- This creates an installable PWA shortcut/app experience. It is not a signed APK.
- For a Play Store APK/AAB, use PWABuilder after the HTTPS site is live, then follow its Android packaging and signing instructions. Play Store distribution requires a paid developer account; Google currently lists a one-time US$25 registration fee. Direct PWA install is the zero-cost route.

ADSTERRA
1. Register/login as a Publisher at https://publishers.adsterra.com/
2. Add and verify your live website URL.
3. Wait for approval and create an ad unit in the Adsterra dashboard.
4. Copy the exact code supplied for your approved unit.
5. In index.html, replace the ad placeholder text inside #ad-top or #ad-bottom with the exact Adsterra code.
6. Test on the live domain. Never click your own ads or ask others to click them.
7. Review ad format rules, privacy/cookie requirements and your audience experience. Avoid intrusive formats that disrupt gameplay.
This package intentionally does NOT contain fake ad code. No revenue is generated until the site is approved, real traffic arrives, and ads serve.

FACEBOOK PAGE SETUP
Page name: GameZone
Username ideas: @PlayGameZoneHQ or @GameZoneMiniGames (availability not guaranteed)
Category: Gaming Video Creator / Video Game
Bio: Play free mini-games, beat your best score and challenge your friends. New games and challenges every week.
Profile image: use icon.svg.
Cover: create a 1640 x 624 gaming banner with the GameZone logo and tagline “PLAY • CHALLENGE • REPEAT”.
CTA: Learn More or Play Now -> your live site URL.
Post 1: “🎮 Welcome to GameZone! Play 30 free mini-games, challenge your reflexes and beat your best score. Start playing: [YOUR WEBSITE LINK]”
Weekly plan: 3 original Reels, 2 game challenge posts, 1 leaderboard/community post. Record your own gameplay and use licensed/original audio. Avoid copied game footage and copyrighted music.
Facebook monetization is separate and eligibility-based; check Professional Dashboard > Monetization.

IMPORTANT BEFORE LAUNCH
- Replace contact email in privacy.html.
- Add your own terms, contact/about pages and cookie disclosure if required.
- Check third-party game/content licences before adding external games.
- This starter includes original simple mini-game mechanics; it does not bundle commercial game assets.
- The included catalogue contains 30 games with eight reusable playable mechanics. It is a starter build, not 30 separate commercial-grade game engines.
